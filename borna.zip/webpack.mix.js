const mix = require('laravel-mix');

/*
 |--------------------------------------------------------------------------
 | Mix Asset Management
 |--------------------------------------------------------------------------
 |
 | Mix provides a clean, fluent API for defining some Webpack build steps
 | for your Laravel application. By default, we are compiling the Sass
 | file for the application as well as bundling up all the JS files.
 |
 */


// mix.js('resources/js/app.js', 'public/js')
//    .sass('resources/sass/app.scss', 'public/css');

mix
    .scripts([
        'resources/js/jquery-3.2.1.slim.min.js', //C:\xampp\htdocs\borna\resources\js\bootstrap.min.js
        'resources/js/popper.min.js',
        'resources/js/bootstrap.min.js',
        // 'resources/js/script.js',
        // 'resources/user/js/jquery-2.1.1.min.js',
        // 'resources/user/js/bootstrap/js/bootstrap.min.js',
        // 'resources/user/js/jquery.easing-1.3.min.js',
        // 'resources/user/js/jquery.dcjqaccordion.min.js',
        // 'resources/user/js/owl.carousel.min.js',
        // 'resources/user/js/custom.js',

        // 'js/jquery-2.1.1.min.js',
        // 'js/bootstrap/js/bootstrap.min.js',
        'revolution/js/jquery.themepunch.tools.min.js?rev=5.0',
        'revolution/js/jquery.themepunch.revolution.min.js?rev=5.0',
        'js/jquery.easing-1.3.min.js',
        'js/jquery.dcjqaccordion.min.js',
        'js/owl.carousel.min.js',
        'js/custom.js',


        'resources/js/script.js',
    ], 'public/js/borna.js')
    .styles([
        // 'resources/css/bootstrap.min.css',
        // 'resources/css/style.css',

        // 'resources/user/js/bootstrap/css/bootstrap.min.css',
        // 'resources/user/js/bootstrap/css/bootstrap-rtl.min.css',
        // 'resources/user/css/font-awesome/css/font-awesome.min.css',
        // 'resources/user/css/stylesheet.css',
        // 'resources/user/css/owl.carousel.css',
        // 'resources/user/css/owl.transitions.css',
        // 'resources/user/css/responsive.css',
        // 'resources/user/css/stylesheet-rtl.css',
        // 'resources/user/css/responsive-rtl.css',
        // 'resources/user/css/stylesheet-skin3.css',

        'resources/user/js/bootstrap/css/bootstrap.min.css',
        'resources/user/js/bootstrap/css/bootstrap-rtl.min.css',
        'resources/user/css/font-awesome/css/font-awesome.min.css',
        'resources/user/css/stylesheet.css',
        'resources/user/css/owl.carousel.css',
        'resources/user/css/owl.transitions.css',
        'resources/user/css/responsive.css',
        'resources/user/css/stylesheet-rtl.css',
        'resources/user/css/responsive-rtl.css',
        'resources/user/css/stylesheet-skin4.css',
        'resources/user/revolution/css/settings.c',
        'resources/user/revolution/css/layers.c',
        'resources/user/revolution/css/navigation.c',


        'resources/css/style.css',
    ], 'public/css/borna.css');
